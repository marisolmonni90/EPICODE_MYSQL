/* Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a:
1) Verificare che i campi definiti come PK siano univoci.  */

SELECT COUNT(DISTINCT ProductID) = COUNT(ProductID) AS ProductID_Unico FROM Product;
SELECT COUNT(DISTINCT RegionID) = COUNT(RegionID) AS RegionID_Unico FROM Region;
SELECT COUNT(DISTINCT SalesID) = COUNT(SalesID) AS SalesID_Unico FROM Sales;

/* 2)Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno */

SELECT Product.ProductName, YEAR(Sales.SaleDate) AS Year, SUM(Sales.TotalAmount) AS TotalRevenue
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
GROUP BY Product.ProductName, YEAR(Sales.SaleDate)
ORDER BY Year, TotalRevenue DESC;

/* 3)Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente */

SELECT Region.RegionName, YEAR(Sales.SaleDate) AS Year, SUM(Sales.TotalAmount) AS TotalRevenue
FROM Sales
JOIN Region ON Sales.RegionID = Region.RegionID
GROUP BY Region.RegionName, YEAR(Sales.SaleDate)
ORDER BY Year, TotalRevenue DESC;

/* 4) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? */

SELECT Product.Category, COUNT(Sales.SalesID) AS SalesCount
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
GROUP BY Product.Category
ORDER BY SalesCount DESC
LIMIT 1;

/* 5) Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */                                                                                      /**/

/* Approccio 1: LEFT JOIN */
SELECT Product.ProductName
FROM Product
LEFT JOIN Sales ON Product.ProductID = Sales.ProductID
WHERE Sales.SalesID IS NULL;

/* Approccio 2: NOT IN */

SELECT ProductName
FROM Product
WHERE ProductID NOT IN (SELECT ProductID FROM Sales);

/* 6) Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/

SELECT Product.ProductName, MAX(Sales.SaleDate) AS LastSaleDate
FROM Sales
JOIN Product ON Sales.ProductID = Product.ProductID
GROUP BY Product.ProductName
ORDER BY LastSaleDate DESC;