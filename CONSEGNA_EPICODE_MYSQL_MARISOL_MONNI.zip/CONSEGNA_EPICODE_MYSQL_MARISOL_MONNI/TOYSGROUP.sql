/* ToysGroup è un’azienda che distribuisce articoli (giocattoli) in diverse aree geografiche del mondo. I prodotti 
sono classificati in categorie e i mercati di riferimento dell’azienda sono classificati in regioni di vendita. 
In particolare: 

Le entità individuabili in questo scenario sono le seguenti: 
1- Product 
2- Region 
3- Sales  
Le relazioni tra le entità possono essere descritte nel modo seguente: 

1) Product e Sales
 1.1) Un prodotto può essere venduto tante volte (o nessuna) per cui è contenuto in una o più transazioni 
di vendita. 
1.2) Ciascuna transazione di vendita è riferita ad uno solo prodotto 

2) Region e Sales
 2.1) Possono esserci molte o nessuna transazione per ciascuna regione 
2.2) Ciascuna transazione di vendita è riferita ad una sola regione  
Fornisci schema concettuale e schema logico.

1) IDENTIFICO LE ENTITA' PRINCIPALI E LE LORO RELAZIONI:
2) PROCEDO CON LO SCHEMA CONCETTUALE UTILIZZANDO IL MODELLO E-R (Entità-Relazione), productproductproductProductIDProductNameCategory
3) SUCESSIVAMENTE CREO LO SCHEMA LOGICO UTILIZZANDO UN MODELLO RELAZIONALE SCHEMA CONCETTUALE (E-R)

ENTITA':
- Product: rappresenta i prodotti/giocattoli venduti dall'azienda.
  Attributi: ProductID (PK), ProductName, Category
- Region: rappresenta le regioni di vendita.
  Attributi: RegionID (PK), RegionName
- Sales: rappresenta le transazioni di vendita.
  Attributi: SalesID (PK), SaleDate, Quantity, TotalAmount

RELAZIONI:
- Product-Sales: Un prodotto può essere venduto in molte transazioni di vendita, e ciascuna transazione di vendita è riferita a un solo prodotto.
  Cardinalità: 1 (Product) a N (Sales)
- Region-Sales: Una regione può avere molte transazioni di vendita, e ciascuna transazione di vendita è riferita a una sola regione.
  Cardinalità: 1 (Region) a N (Sales)
  
  
  +------------+     1:N     +------------+
|  Product   |-------------|   Sales    |
+------------+             +------------+
| ProductID  |             | SalesID    |
| ProductName|             | SaleDate   |
| Category   |             | Quantity   |
+------------+             | TotalAmount|
                           | ProductID  |
                           | RegionID   |
                           +------------+
                                 |
                                 |
                                N:1
                                 |
                           +------------+
                           |   Region   |
                           +------------+
                           | RegionID   |
                           | RegionName |
                           +------------+

Schema Logico (Modello Relazionale)

TABELLE:
- Product
  ProductID (PK)
  ProductName
- Category
  Region
  RegionID (PK)
  RegionName
- Sales
  SalesID (PK)
  SaleDate
  Quantity
  TotalAmount
  ProductID (FK che riferisce Product.ProductID)
  RegionID (FK che riferisce Region.RegionID)
*/


CREATE SCHEMA ToysGroup;
USE ToysGroup;


CREATE TABLE Product (
    ProductID INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    ProductName VARCHAR(100) NOT NULL,
    Category VARCHAR(50) NOT NULL
);


CREATE TABLE Region (
    RegionID INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    RegionName VARCHAR(100) NOT NULL
);


CREATE TABLE Sales (
    SalesID INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    SaleDate DATE,
    Quantity INT,
    TotalAmount DECIMAL(10, 2),
    ProductID INT NOT NULL,
    RegionID INT NOT NULL,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID) 
    ON delete cascade
    ON update cascade
);


